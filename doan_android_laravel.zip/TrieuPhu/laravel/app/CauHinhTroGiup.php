<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CauHinhTroGiup extends Model
{
    //
    protected $table = "cau_hinh_tro_giup";
}
