 <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="">Colorlib</a>
          </div>
          <div class="clearfix"></div>
 </footer><?php /**PATH D:\GitHub\TrieuPhu\laravel\resources\views/partials/footer.blade.php ENDPATH**/ ?>