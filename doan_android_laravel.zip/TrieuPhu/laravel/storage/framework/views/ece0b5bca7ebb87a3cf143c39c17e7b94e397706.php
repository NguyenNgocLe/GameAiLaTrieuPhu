<?php $__env->startSection('page_content'); ?>
<div class="modal-dialog">
  <div class="modal-content">
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-danger">
                <ul style="list-style-type:none;">
                  <li><?php echo e($error); ?></li>
                </ul>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    <form action="<?php echo e(route('cau_hoi.xu_li_them')); ?>" id="form-add-linh-vuc" method="POST" role="form">
      <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h4 class="modal-title">Thêm lĩnh vực</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="">Lĩnh vực</label>
          <select name="id_type" id="id_type" class="form-control" >
            <?php $__currentLoopData = $lvuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($ds1->id); ?>"><?php echo e($ds1->ten_linh_vuc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label for="">Nội dung</label>
          <input name="noi_dung" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án A</label>
          <input name="dap_an_a" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án B</label>
          <input name="dap_an_b" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án C</label>
          <input name="dap_an_c" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án D</label>
          <input name="dap_an_d" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Đáp án </label>
          <input name="dap_an" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
      </div>
      <div class="modal-footer">
        <a href="<?php echo e(route('cau_hoi.danh_sach')); ?>" class="btn btn-default" data-dismiss="modal">Back</a>
        <button type="submit" class="btn btn-primary">Thêm</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\download\TrieuPhu\TrieuPhu\laravel\resources\views/cau_hoi/xl_cau_hoi.blade.php ENDPATH**/ ?>