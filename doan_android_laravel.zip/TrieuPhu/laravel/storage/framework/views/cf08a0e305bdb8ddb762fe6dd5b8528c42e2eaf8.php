<div class="right_col" role="main">
          <!-- top tiles -->
          <?php echo $__env->yieldContent('page_content'); ?>
</div><?php /**PATH D:\GitHub\TrieuPhu\laravel\resources\views/partials/page_content.blade.php ENDPATH**/ ?>