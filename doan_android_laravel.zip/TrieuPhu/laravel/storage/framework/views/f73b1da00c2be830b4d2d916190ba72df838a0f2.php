 <footer>
      
 </footer><?php /**PATH D:\download\TrieuPhu\TrieuPhu\laravel\resources\views/partials/footer.blade.php ENDPATH**/ ?>