@extends('partials.layout')
@section('page_content')
<div class="modal-dialog">
  <div class="modal-content">
    @if($errors->any())
      @foreach($errors->all() as $error)
              <div class="alert alert-danger">
                <ul style="list-style-type:none;">
                  <li>{{$error}}</li>
                </ul>
              </div>
          @endforeach
      @endif
    <form action="{{route('cau_hoi.xu_li_them')}}" id="form-add-linh-vuc" method="POST" role="form">
      @csrf
      <div class="modal-header">
        <h4 class="modal-title">Thêm lĩnh vực</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="">Lĩnh vực</label>
          <select name="id_type" id="id_type" class="form-control" >
            @foreach($lvuc as $ds1)
              <option value="{{$ds1->id}}">{{$ds1->ten_linh_vuc}}</option>
            @endforeach
          </select>
        </div>
        <div class="form-group">
          <label for="">Nội dung</label>
          <input name="noi_dung" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án A</label>
          <input name="dap_an_a" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án B</label>
          <input name="dap_an_b" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án C</label>
          <input name="dap_an_c" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Phương án D</label>
          <input name="dap_an_d" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
        <div class="form-group">
          <label for="">Đáp án </label>
          <input name="dap_an" type="text" class="form-control" id="ten_linh_vuc" >
        </div>
      </div>
      <div class="modal-footer">
        <a href="{{route('cau_hoi.danh_sach')}}" class="btn btn-default" data-dismiss="modal">Back</a>
        <button type="submit" class="btn btn-primary">Thêm</button>
      </div>
    </form>
  </div>
</div>
@endsection