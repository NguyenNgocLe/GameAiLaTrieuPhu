package com.nvk.doanailatrieuphu.Controller;

public class LuotChoiController {
    public static final String COLUMN_NGUOI_CHOI_ID = "nguoi_choi_id";
    public static final String COLUMN_LUOT_CHOI_SO_CAU = "so_cau";
    public static final String COLUMN_LUOT_CHOI_DIEM = "diem";
    public static final String COLUMN_LUOT_CHOI_NGAY_GIO = "ngay_gio";
}
