<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\LinhVuc;
use Illuminate\Support\Facades\DB;
class LinhVucController extends Controller
{
    public function getLinhVuc(Request $request)
    {
        $page = $request->page;
        $limit = $request->limit;
        $linhVuc = LinhVuc::skip(($page-1)*$limit)->take($limit)->get();
        $result = [
            'success' => true,
            'total' => LinhVuc::count(),
            'linh_vuc' => $linhVuc
        ];
        return response()->json($result);
    }

    


    public function layapi(Request $request)
    {
        $page = $request->page;
        $limit = $request->limit;
        $linhvuc = LinhVuc::all();
        $result = [
            'success' => true,
            'total' => LinhVuc::count(),
            'linh_vuc' => $linhvuc,
        ];
        return response()->json($result);
    }
}
