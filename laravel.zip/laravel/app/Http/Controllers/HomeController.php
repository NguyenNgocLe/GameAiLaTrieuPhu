<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\QuanTriVien;
class HomeController extends Controller
{
	public function index(){
        return View('home');
    }
    public function view_login(){
        return View('login');
    }
    public function login(Request $rq)
    {
    	//kiem tra nguoi dung nhap chua
    	if(Auth::attempt(['ten_dang_nhap'=>$rq->l_username,'password'=>$rq->l_password]))
    	{
            $rq->session()->put('name',Auth::User()->ho_ten);
			return view('home');
    	}
    	else{
            return redirect()->back()->with('error','username hoặc mật khẩu sai');
        }
    }

    public function Logout(Request $rq)
    {
    	$rq->session()->flush();
        Auth::logout();
        return redirect('/');
    }
}
