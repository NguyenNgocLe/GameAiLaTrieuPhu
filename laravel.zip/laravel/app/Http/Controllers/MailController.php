<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use Hash;
use App\QuanTriVien;
class MailController extends Controller
{

	public function view_reset_pass()
    {
        return view('mail.form-reset-pass');
    }

    // hàm gửi mail
    public function sendMail(Request $rq)
    {
    	$this->validate($rq,
    		[
    			's_email'=>'required|email',
    		],
    		[
    			's_email.email'=>'Email không đúng định dạng',
    			's_email.required'=>'Email không được để trống',
    		]
    	);
    	
        $data = array('email'=>$rq->s_email,'code'=>Hash::make($rq->s_email));
        //dd($data['email']);
        Mail::send('mail.title',$data,function($message) use ($data){
            $message->to($data['email'],'Admin')->subject('Lấy lại mật khẩu');
        });
        return back()->with('success','Gửi xác nhận thành công');
    }


    //hàm khi người dùng click vào link trên hộp thư gmail chuyển tới trang đặt lại mật khẩu
    public function view_new_pass($code)
    {

        $listUser = QuanTriVien::all();
        foreach ($listUser as $value) {
        	//dd($value->ten_dang_nhap);
        	$dump = Hash::make($value->ten_dang_nhap);
            if(Hash::check($value->ten_dang_nhap,$code))
            {
                $user = QuanTriVien::where('ten_dang_nhap',$value->ten_dang_nhap)->get();
                //dd($user);
                return view('mail.form-new-pass',compact('user'));
                break;
            }
        }
    }

    //hàm đặt lại mật khẩu theo id người dùng
    public function NewPass($id,Request $rq)
    {
        $this->validate($rq,
            [
                'password'=>'required|same:re-password',
                're-password'=>'required',
            ],
            [
                'password.required'=>'Vui lòng nhập mật khẩu mới',
                're-password'=>'Vui lòng nhập lại mật khẩu mới',
                'password.same'=>'Mật khẩu không khớp',
            ]
        );
        $user = QuanTriVien::find($id);
        //dd($user);
        $user->password = Hash::make($rq->password);
        $user->save();
        return redirect()->route('login');
    }
}
