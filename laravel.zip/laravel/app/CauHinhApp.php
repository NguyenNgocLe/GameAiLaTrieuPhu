<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CauHinhApp extends Model
{
    protected $table = "cau_hinh_app";
}
