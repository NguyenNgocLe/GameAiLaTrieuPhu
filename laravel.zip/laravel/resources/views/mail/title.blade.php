<br>
<p>Cảm ơn quý khách đã ủng hộ tiệm bánh trong thời gian gần đây vui lòng quý xác click vào để đặt lại mật khẩu <a href="{{route('view-reset-pass',['code'=>$code])}}">{{$code}}</a></p>