 <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              {{-- <span>Welcome,</span> --}}
                  @if(Session::has('name'))
                      <h4>Xin chào admin</h4>
                      <center>{{Session::get('name')}}</center>
                  @endif
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_info">
                
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li><a href="{{route('index')}}"><i class="fa fa-home"></i> Trang Chủ <span class="fa fa-chevron-down"></span></a>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Bảng <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="{{ route('linh_vuc.danh_sach') }}">Lĩnh Vực</a></li>
                      <li><a href="{{ route('nguoi_choi.danh_sach') }}">Người Chơi</a></li>
                      <li><a href="{{ route('goi_credit.danh_sach') }}">Gói Credit</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-copy"></i> Bảng Phụ <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ route('cau_hoi.danh_sach') }}">Câu Hỏi</a></li>
                      <li><a href="{{ route('chi_tiet_luot_choi.danh_sach') }}">Chi Tiết Lượt Chơi</a></li>
                      <li><a href="{{ route('luot_choi.danh_sach') }}">Lượt Chơi</a></li>
                      <li><a href="{{ route('lich_su_mua_credit.danh_sach') }}">Lịch Sử Mua Credit</a></li>
                      <li><a href="{{ route('chi_tiet_luot_choi.danh_sach') }}">Chi Tiết lượt chơi</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-desktop"></i> Cấu Hình <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{ route('quan_tri_vien.danh_sach') }}">Quản Trị Viên</a></li>
                      <li><a href="{{ route('cau_hinh_app.danh_sach') }}">App</a></li>
                      <li><a href="{{ route('cau_hinh_tro_giup.danh_sach') }}">Trợ Giúp</a></li>
                      <li><a href="{{ route('cau_hinh_diem_cau_hoi.danh_sach') }}">Điểm Câu Hỏi</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
              <div class="menu_section">
                <h3>Live On</h3>
                <ul class="nav side-menu">
                   <li><a><i class="fa fa-code"></i> Json <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="{{route('api-linh-vuc')}}">Lĩnh Vực</a></li>
                      <li><a href="/api/nguoi_choi">Người Chơi</a></li>
                      <li><a href="/api/cau_hoi">Câu Hỏi</a></li>
                      <li><a href="/api/goi_credit">Gói Credit</a></li>
                      <li><a href="/api/luot_choi">Lượt Chơi</a></li>
                    </ul>
                  </li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <!-- /menu footer buttons -->
          </div>
        </div>