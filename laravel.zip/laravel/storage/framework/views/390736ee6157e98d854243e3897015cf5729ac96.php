<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gentelella Alela! | </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="../vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>
      <div class="login_wrapper">
        <div class="animate form login_form">
          <?php if(Session::has('error')): ?>
            <div class="alert alert-danger">
              <?php echo e(Session::get('error')); ?>

            </div>
          <?php endif; ?>
          <section class="login_content">
          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="POST" action="<?php echo e(route('xu-ly-reset-pass',['id'=>$ds->id])); ?>">
              <?php echo csrf_field(); ?>
              <h1>Reset-password</h1>
              <div>
                <input type="password" name="password" class="form-control" placeholder="Mật khẩu mới" required="" />
              </div>
              <div>
                <input type="password" name="re-password" class="form-control" placeholder="Nhập lại mật khẩu mới" required="" />
              </div>
              <div>
                <input type="submit" class="btn btn-success" name="" value="Đồng ý">
              </div>
            </form>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </section>
        </div>
      </div>
    </div>
  </body>
</html>
<?php /**PATH D:\download\TrieuPhu\TrieuPhu\laravel\resources\views/mail/form-new-pass.blade.php ENDPATH**/ ?>