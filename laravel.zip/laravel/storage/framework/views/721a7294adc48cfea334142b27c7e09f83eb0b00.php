<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
  <head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">

        <?php echo $__env->make('partials.left_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

        <?php echo $__env->make('partials.top_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- page content -->
        <?php echo $__env->make('partials.page_content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /page content -->

        <!-- footer content -->
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /footer content -->
      </div>
    </div>

    <?php echo $__env->make('partials.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html>
<?php /**PATH D:\ProjectAndroid\laravel\resources\views/partials/layout.blade.php ENDPATH**/ ?>