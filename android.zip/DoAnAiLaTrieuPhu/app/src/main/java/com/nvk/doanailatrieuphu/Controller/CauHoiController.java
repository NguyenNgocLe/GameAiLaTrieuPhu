package com.nvk.doanailatrieuphu.Controller;

public class CauHoiController {
    private static final String TABLE_CAUHOI = "cauhoi";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NOI_DUNG = "noi_dung";
    public static final String COLUMN_LINH_VUC_ID = "linh_vuc_id";
    private static final String COLUMN_PHUONG_AN_A = "phuong_an_a";
    private static final String COLUMN_PHUONG_AN_B = "phuong_an_b";
    private static final String COLUMN_PHUONG_AN_C = "phuong_an_c";
    private static final String COLUMN_PHUONG_AN_D = "phuong_an_d";
    private static final String COLUMN_DAP_AN = "dap_an";
    private static final String COLUMN_XOA = "xoa";

}
